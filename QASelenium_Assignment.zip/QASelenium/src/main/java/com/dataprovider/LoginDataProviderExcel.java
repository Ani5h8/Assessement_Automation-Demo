package com.dataprovider;

import org.testng.annotations.DataProvider;
import com.util.ActionProvider;

public class LoginDataProviderExcel {

	ActionProvider util = new ActionProvider();

	@DataProvider(name = "loginDPExcel")
	public String[][] loginTestDataProvider() {
		String data[][] = ActionProvider.readExcelTestData("testData", "userCredentials");

		return data;

	}

}