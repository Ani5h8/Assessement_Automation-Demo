package com.pages;

import java.text.ParseException;

import com.util.ActionProvider;

public class Erail extends ActionProvider {
	
	public static String Station ="//input[@title='Type SOURCE station code or name']";
	public static String newStation = "//div[@class='autocomplete']/child::div[4]";
	public static String date="//input[@title='Select Departure date for availability']";
	
	public void clickonfromstationAndType() {
		clickandType(Station,"DEL");
	}
	
	public void selectStationandPrint() {
		clickandPrint(newStation);
		
	}
	public void selectdate() throws ParseException, InterruptedException {
		selectandsortdate(date,30);
	}
	
	
	

}
