package com.pages;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.util.ActionProvider;

public class OrangeHRM extends ActionProvider{
	public static ExtentReports report;
	public static ExtentTest test;

	
	public static String Username ="//input[@name='username']";
	public static String Password ="//input[@name='password']";
	public static String SubmitButton="//button[@type='submit']";
	public static String DashBoard="//span[@class='oxd-topbar-header-breadcrumb']";
	public static String MyActions = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[2]/div/div[1]/div/p";
			
	
	public void EnterUsername(String User) {
		clickandType(Username,User);
	}
	
	public void EnterPassword(String Pass) {
		clickandType(Password,Pass);
	}
	
	public void SubmitButton() {
		click(SubmitButton);
	}
	
	public void DashboardisVisible() throws InterruptedException {
		isvisible(DashBoard);
	}
	


}
