package com.seleniumscript;

import java.io.IOException;
import java.text.ParseException;

import com.pages.Erail;
import com.relevantcodes.extentreports.ExtentReports;
import com.util.ActionProvider;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
public class User_Test_Erail {
	
	public static ExtentReports report;
	public static ExtentTest test;
	
	public static void startTest() {
		{
			report = new ExtentReports(System.getProperty("user.dir")+"//test-output//"+"//Test_Rail_ExtentReports.html");
			test = report.startTest("User_Test_Erail");
			}
		
	}
	public static void endTest()
	{
	report.endTest(test);
	report.flush();
	}

	public static void main(String[] args) throws ParseException, IOException, InterruptedException {
		
		ActionProvider util = new ActionProvider();
		startTest();
		Erail rail = new Erail();
		util.webDriverInitialize();
		util.goToWebSite("https://erail.in/");
		test.log(LogStatus.PASS, "WebsiteOpened Successfully");
		rail.clickonfromstationAndType();
		test.log(LogStatus.PASS, "Station Clicked Successfully");
		rail.selectStationandPrint();
		test.log(LogStatus.PASS, "4th Station Selected Successfully");
		util.SaveStationsandCopyToExcel();
		test.log(LogStatus.PASS, "10 Station Names Fetched Saved in Excel Successfully");
		util.compareExcelSheets();
		test.log(LogStatus.PASS, "All the fetched stations are present in Expected Station list");
		rail.selectdate();
		test.log(LogStatus.PASS, "30+ Days Date Selected Successfully");
		util.quitWebDriver();
		test.log(LogStatus.PASS, "WebDriverClosed Successfully");
		endTest();
		
	}

}
