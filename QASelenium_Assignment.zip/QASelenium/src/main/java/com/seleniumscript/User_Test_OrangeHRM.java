package com.seleniumscript;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.pages.OrangeHRM;
import com.util.ActionProvider;

public class User_Test_OrangeHRM extends ActionProvider {

	ActionProvider util = new ActionProvider();
	OrangeHRM HRM = new OrangeHRM();
	public static ExtentTest test;
	public static ExtentReports report;

	@BeforeClass(description = "Reporting Started")
	public static void startTest() {
		{
			report = new ExtentReports(
					System.getProperty("user.dir") + "//test-output//" + "//Orange_HRM_ExtentReports.html");
			test = report.startTest("User_Test_OrangeHRM");
		}

	}

	@BeforeMethod(description = "Initialization of session")
	public void setup() throws InterruptedException {
		util.webDriverInitialize();
		util.goToWebSite("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	@Test(description = "Initialization of session", dataProviderClass = com.dataprovider.LoginDataProviderExcel.class, dataProvider = "loginDPExcel")
	public void login(String User, String Pass) throws InterruptedException {
		System.out.println(User);
		System.out.println(Pass);
		HRM.EnterUsername(User);
		test.log(LogStatus.PASS, "username Passed");
		HRM.EnterPassword(Pass);
		test.log(LogStatus.PASS, "Password Passed");
		HRM.SubmitButton();
		try {
			HRM.DashboardisVisible();
			test.log(LogStatus.PASS, "login Successfull");
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "login Failed because wrong Credentials");
		}
	}

	@AfterMethod(description = "Closing WebDriver")
	public void closeDriver() throws InterruptedException {
		util.quitWebDriver();
	}

	@AfterClass
	public static void endTest() {
		report.endTest(test);
		report.flush();
	}
}
