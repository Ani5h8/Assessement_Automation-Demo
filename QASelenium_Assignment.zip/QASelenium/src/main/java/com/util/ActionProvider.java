package com.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import com.relevantcodes.extentreports.ExtentTest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class ActionProvider {

	public static ChromeDriver wd;
	public static ExtentTest test;
	public WebDriverWait wait;

	public void webDriverInitialize() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//Drivers//chromedriver.exe");
		wd = new ChromeDriver();
		wd.manage().window().maximize();

	}

	public void quitWebDriver() {
		wd.quit();
	}

	public void goToWebSite(String url) {
		wd.get(url);
	}

	public void clickandType(String Xpath, String Value) {
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement Element = wd.findElement(By.xpath(Xpath));
		Element.click();
		Element.clear();
		Element.sendKeys(Value);

	}

	public void click(String Xpath) {
		WebElement Element = wd.findElement(By.xpath(Xpath));
		Element.click();
	}

	public void clickandPrint(String Xpath) {
		wd.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		WebElement Element = wd.findElement(By.xpath(Xpath));
		Element.click();
		String name = Element.getAttribute("Title");
		System.out.println("The Station Selected is " + name);
	}

	public void selectandsortdate(String Xpath, int Days_Added) throws ParseException, InterruptedException {
		WebElement DateNew = wd.findElement(By.xpath(Xpath));
		DateNew.click();
		Thread.sleep(2000);
		String Current_Date = DateNew.getAttribute("value");
		Date date1 = new SimpleDateFormat("dd-MMM-yy E").parse(Current_Date);
		SimpleDateFormat DateFor = new SimpleDateFormat("dd-MMM-yy E");
		String Date = DateFor.format(date1);
		System.out.println("Current Date is : " + Date);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date1);
		cal.add(Calendar.DAY_OF_MONTH, Days_Added);
		// String dateAfter = DateFor.format(cal.getTime());
		SimpleDateFormat DateFor1 = new SimpleDateFormat("MMM-yy");
		String dateAfter1 = DateFor1.format(cal.getTime());
		SimpleDateFormat DateFor2 = new SimpleDateFormat("dd");
		String dateAfter2 = DateFor2.format(cal.getTime());
		WebElement new1 = wd.findElement(By.xpath("//table[@class='Month']/tbody/tr/td[text()='" + dateAfter1
				+ "']/../following-sibling::tr/td[text()='" + dateAfter2 + "']"));
		new1.click();
		Thread.sleep(2000);
	}

	public static String[][] readExcelTestData(String fileName, String sheetName) {

		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook(System.getProperty("user.dir") + "//testData//" + fileName + ".xlsx");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		XSSFSheet mySheet = myWorkBook.getSheet(sheetName);
		int lastRowIndexInSheet = mySheet.getLastRowNum();
		System.out.println(lastRowIndexInSheet); // counting starts from 0
		XSSFRow rowHeader = mySheet.getRow(0); // Column Names
		int totalNumberOfColsInSheet = rowHeader.getLastCellNum();
		System.out.println(totalNumberOfColsInSheet);
		XSSFRow myRow;
		XSSFCell myCell;
		String myData[][] = new String[lastRowIndexInSheet][totalNumberOfColsInSheet];
		// For loop for the 2 DArray
		for (int row = 1; row <= lastRowIndexInSheet; row++) {
			for (int col = 0; col < totalNumberOfColsInSheet; col++) {
				myRow = mySheet.getRow(row);
				myCell = myRow.getCell(col);
				// System.out.print(myCell + " ");
				myData[row - 1][col] = myCell.toString();// Intializing the 2d array
			}
		}
		return myData;
	}

	public void TitleValidate(String Expected_title) {
		String Actual_Title = wd.getTitle();
		Assert.assertEquals(Actual_Title, Expected_title);
	}

	public void isvisible(String Xpath) throws InterruptedException {
		Thread.sleep(5000);
		WebElement Element = wd.findElement(By.xpath(Xpath));
		Thread.sleep(2000);
		Assert.assertEquals(Element.isDisplayed(), true);
	}

	public void SaveStationsandCopyToExcel() throws IOException {
		List<String> title = new LinkedList<String>();
		for (int a = 1; a <= 10; a++) {
			WebElement NextStation = wd.findElement(By.xpath("//div[@class='autocomplete']/child::div[" + a + "]"));
			String next = NextStation.getAttribute("Title");
			title.add(next);
		}
		Iterator<String> it1 = title.iterator();
		while (it1.hasNext()) {
			for (int i = 0; i < 10; i++) {
				String newname = it1.next();
				System.out.println(newname);
				String file = System.getProperty("user.dir") + "//testData//StationNamesfromDropdown.xlsx";
				FileInputStream fileInputStream = new FileInputStream(file);
				XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
				XSSFSheet sheet = workbook.getSheet("Sheet1");
				sheet.setColumnWidth(0, 1000);
				Row row = sheet.createRow(i);
				Cell cell = row.createCell(0);
				cell.setCellValue(newname);
				FileOutputStream fileOutputStream = new FileOutputStream(file);
				workbook.write(new FileOutputStream(file));
				fileInputStream.close();
				fileOutputStream.close();
			}

		}

	}

	public void compareExcelSheets() throws IOException {
		String file = System.getProperty("user.dir") + "//testData//StationNamesfromDropdown.xlsx";
		FileInputStream fileInputStream = new FileInputStream(file);
		try (XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream)) {
			Sheet sheet1 = workbook.getSheetAt(0);
			Sheet sheet2 = workbook.getSheetAt(1);
			Iterator<Row> rowIterator1 = sheet1.iterator();
			Iterator<Row> rowIterator2 = sheet2.iterator();
			while (rowIterator1.hasNext() && rowIterator2.hasNext()) {
				Row currentRow1 = rowIterator1.next();
				Row currentRow2 = rowIterator2.next();
				Iterator<Cell> cellIterartor1 = currentRow1.iterator();
				Iterator<Cell> cellIterartor2 = currentRow2.iterator();
				while (cellIterartor1.hasNext() && cellIterartor2.hasNext()) {
					Cell currentCell1 = cellIterartor1.next();
					Cell currentCell2 = cellIterartor2.next();
					String actualStation = currentCell1.getStringCellValue();
					String expectedStation = currentCell2.getStringCellValue();
					if (actualStation.equals(expectedStation)) {
						System.out.println(currentCell1 + " is present in both Expected and Actual Station list");
					} else {
						System.out.println(currentCell1 + " is not present in Expected Station list");
					}
					Assert.assertEquals(actualStation, expectedStation);
				}

			}
		}
	}

}
